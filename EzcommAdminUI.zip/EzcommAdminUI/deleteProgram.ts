import axios from 'axios';

/**
 * Delete a program by smsManagerSettingId (settingId).
 * Returns an object containing HTTP status and backend response body fields.
 */
export const deleteProgram = async (settingId: number) => {
  try {
    const response = await axios.delete(`/admin/program-ids/${settingId}`);
    // Return status plus response body fields for easier handling in UI
    return { status: response.status, ...(response.data || {}) };
  } catch (err: any) {
    if (err.response) {
      // Return status plus backend body (e.g., conflict details)
      return { status: err.response.status, ...(err.response.data || { success: false, message: err.message }) };
    }
    return { status: 500, success: false, message: err.message || 'Unknown error' };
  }
};
