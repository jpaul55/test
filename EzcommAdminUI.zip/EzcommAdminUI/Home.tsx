import React from 'react';
import { Button } from '@uhg-abyss/web/ui/Button';
import { Heading } from '@uhg-abyss/web/ui/Heading';
import { Layout } from '@uhg-abyss/web/ui/Layout';
import { Router } from '@uhg-abyss/web/ui/Router';
import 'bootstrap/dist/css/bootstrap.min.css';
import MemberDetailsHeader from '../../common/MemberDetailsHeader/MemberDetailsHeader';
import ContactInformationComponent from '../../common/ContactInformationComponent/ContactInformationComponent';
import MessageConsentLanguage from '@src/common/MessageConsentLanguage/MessageConsentLanguage';

export const Home = () => {
  return (
    <React.Fragment>
      <Router.MetaTags title="Home" />
      <Layout.Stack alignLayout="center">
        <Heading textAlign="center">Welcome to Abyss</Heading>
        <Button href="/hello-abyss">Say hello!</Button>
        <MemberDetailsHeader memberId="123456789" name="John abc" dob="01/01/1900" />
        <ContactInformationComponent />
        <MessageConsentLanguage />
      </Layout.Stack>
    </React.Fragment>
  );
};
