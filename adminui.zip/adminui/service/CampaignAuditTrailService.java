package com.optum.riptide.ezcommui.adminui.service;

import com.optum.riptide.ezcommui.adminui.entities.CampaignAudit;
import com.optum.riptide.ezcommui.adminui.entities.MenuEntity;
import com.optum.riptide.ezcommui.adminui.enums.AuditAction;
import com.optum.riptide.ezcommui.adminui.model.AuditTrailCampaignFilterModel;
import com.optum.riptide.ezcommui.adminui.model.AuditTrailModel;
import com.optum.riptide.ezcommui.adminui.repository.CampaignAuditRepository;
import com.optum.riptide.ezcommui.adminui.utils.DateTimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Objects;

@Service
public class CampaignAuditTrailService {

    private final CampaignAuditRepository campaignAuditRepository;

    @Autowired
    public CampaignAuditTrailService (final CampaignAuditRepository campaignAuditRepository) {
        this.campaignAuditRepository = campaignAuditRepository;
    }

    public void createAuditTrail(final MenuEntity menuEntity, final String action, final String oldValue,
                                 final String newValue, final Timestamp timestamp, final String userId) {
        final CampaignAudit campaignAudit = new CampaignAudit();
        campaignAudit.setMenuEntityId(menuEntity.getMenuEntityId());
        campaignAudit.setAction(action);
        campaignAudit.setOldValue(oldValue);
        campaignAudit.setTimestamp(timestamp);
        campaignAudit.setNewValue(newValue);
        campaignAudit.setUserId(userId);
        campaignAuditRepository.save(campaignAudit);
    }

    public String auditTrailValue(final MenuEntity entity, final String urlLink, final String urlLabel, final Long standardTemplateId, final Long clientContextId
    ,final String interactionType, final List<AuditTrailCampaignFilterModel> campaignFilter) {
        return new AuditTrailModel(entity.getMenuEntityId(), entity.getName(), urlLink, urlLabel, entity.getCampaign().getCampaignId(),
                standardTemplateId, clientContextId, interactionType, campaignFilter, entity.getSubjectLine(), entity.getDisclaimer(), entity.getSenderEmail()).convertToJson();
    }

    public void saveAuditTrail(final AuditTrailModel oldAudit, final AuditTrailModel newAudit, final long menuId, final String userId, AuditAction action) {
        final CampaignAudit campaignAudit = new CampaignAudit();
        campaignAudit.setMenuEntityId(menuId);
        campaignAudit.setAction(action.toString());
        campaignAudit.setOldValue(oldAudit.convertToJson());
        campaignAudit.setNewValue(newAudit.convertToJson());
        campaignAudit.setUserId(userId);
        campaignAudit.setTimestamp(DateTimeUtils.formatNow());
        campaignAuditRepository.save(campaignAudit);
    }
}
