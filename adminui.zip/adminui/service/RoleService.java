package com.optum.riptide.ezcommui.adminui.service;

import com.optum.riptide.ezcommui.adminui.constants.AdminUiPropertiesBean;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

@Service
public class RoleService {

    private final AdminUiPropertiesBean adminUiPropertiesBean;

    @Autowired
    public RoleService(AdminUiPropertiesBean adminUiPropertiesBean) {
        this.adminUiPropertiesBean = adminUiPropertiesBean;
    }

    public List<String> checkAdminLobs(List<String> userRoles) {
        final List<String> userGroups = userRoles.stream()
                .map(t -> t.split(",")[0].split("=")[1])
                .filter(t -> t.contains(adminUiPropertiesBean.rolePrefix))
                .collect(Collectors.toList());
        Collections.sort(userGroups);

        final List<String> lineOfBusinessList;
        if (userGroups.size() == 0) {
            throw new AccessDeniedException("No sufficient privilege");
        } else if (userGroups.contains(adminUiPropertiesBean.rolePrefix)) {
            lineOfBusinessList = Collections.singletonList(adminUiPropertiesBean.roleAll);
        } else {
            String adminPattern = "^" + adminUiPropertiesBean.rolePrefix + "_..\\z";
            Pattern pattern = Pattern.compile(adminPattern);
            lineOfBusinessList = userGroups.stream()
                    .filter(t -> pattern.matcher(t).find())
                    .map(t -> t.substring(adminUiPropertiesBean.rolePrefix.length() + 1).toUpperCase())
                    .collect(Collectors.toList());
            if (lineOfBusinessList.size() == 0) {
                throw new AccessDeniedException("No sufficient privilege");
            }
        }
        return lineOfBusinessList;
    }
}
