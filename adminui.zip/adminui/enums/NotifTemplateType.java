package com.optum.riptide.ezcommui.adminui.enums;

public enum NotifTemplateType {

    EMAIL("EMAIL-ONLY"),
    SMS("SMS-ONLY"),
    BOTH("BOTH"),
    FAX("");

    private String interactionType;

    NotifTemplateType(final String interactionType) {
        this.interactionType = interactionType;
    }

    public String getInteractionType() {
        return interactionType;
    }

}
