package com.optum.riptide.ezcommui.adminui.enums;

public enum AuditAction {

    CREATE,
    UPDATE,
    DELETE;

}
