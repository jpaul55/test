package com.optum.riptide.ezcommui.adminui.utils;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import org.apache.commons.lang3.StringUtils;

public class DateTimeUtils {

    public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static Timestamp formatNow() {
        return new Timestamp(GregorianCalendar.getInstance().getTimeInMillis());
    }


    public static boolean validate(String input, String dateFormat) {

        try {
            final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            sdf.setLenient(false);
            sdf.parse(input);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public static Date toDate(final String dateString) throws ParseException {
        final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        if (StringUtils.isBlank(dateString)) {
            return null;
        }
        return sdf.parse(dateString);
    }

    public static Timestamp toSqlTimestamp(final String dateString, final String timeZoneId) throws ParseException {
        final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        if (StringUtils.isBlank(dateString)) {
            return null;
        }
        sdf.setTimeZone(TimeZone.getTimeZone(timeZoneId));
        return new Timestamp(sdf.parse(dateString).getTime());
    }

    public static String toStringDate(final Timestamp timestamp) {
        if (timestamp == null) {
            return null;
        }
        final SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        return sdf.format(new Date(timestamp.getTime()));
    }
}
