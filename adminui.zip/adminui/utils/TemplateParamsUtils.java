package com.optum.riptide.ezcommui.adminui.utils;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.List;

public class TemplateParamsUtils {

    public static String extractUrlLink(final String templateParam) {
        if (templateParam == null || templateParam.length() <= 2) {
            return "";
        }
        JsonObject obj = new JsonParser().parse(TemplateParamsUtils.cleanTemplateParams(templateParam)).getAsJsonObject();
        JsonObject obj2 = obj.get("msg_parameters").getAsJsonObject().get("template").getAsJsonObject();
        return obj2.get("urlLink").getAsString();
    }

    public static String extractUrlLabel(final String templateParam) {
        if (templateParam == null || templateParam.length() <= 2) {
            return "";
        }
        JsonObject obj = new JsonParser().parse(TemplateParamsUtils.cleanTemplateParams(templateParam)).getAsJsonObject();
        JsonObject obj2 = obj.get("msg_parameters").getAsJsonObject().get("template").getAsJsonObject();
        return obj2.get("urlLabel").getAsString();
    }


  public static String cleanTemplateParams(String templateParams) {
    // Step 1: Remove unnecessary escape characters for JSON parsing
    StringBuilder stringBuilder = new StringBuilder(templateParams.replace("\\\"", "\""));

    // Step 2: Further clean up by removing unnecessary backslashes not escaping a quote
    List<Integer> indexList = new ArrayList<>();
    for (int i = 0; i < stringBuilder.length(); i++) {
      char currentChar = stringBuilder.charAt(i);
      if (currentChar == '\\' && (i + 1 < stringBuilder.length() && stringBuilder.charAt(i + 1) != '"')) {
        indexList.add(i);
      }
    }

    // Removing identified backslashes in reverse order to not mess up the indexing
    for (int i = indexList.size() - 1; i >= 0; i--) {
      int index = indexList.get(i);
      stringBuilder.deleteCharAt(index);
    }

    return stringBuilder.toString();
  }

}
