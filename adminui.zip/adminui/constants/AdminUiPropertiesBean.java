package com.optum.riptide.ezcommui.adminui.constants;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * User: jsticha Date: 12/4/2016 Time: 7:38 PM
 *
 * <p>Created with IntelliJ IDEA To change this template use File | Settings | File Templates.
 */
@Slf4j
@Getter
@Component
public class AdminUiPropertiesBean {
  /***
   * Properties from application.properties
   ***/

  @Value("${oidc.group.attribute.name}")
  public String groupAttributeName;

  @Value("${ezcomm.admin.role.prefix}")
  public String rolePrefix;

  @Value("${ezcomm.admin.role.all}")
  public String roleAll;

  @Value("${ezcomm-core.menus-endpoint}")
  public String menuEntityUrl;

  @Value("${ezcomm-core.menus-endpoint}")
  public String templateUrl;

  public Map toMap() {
    return new ObjectMapper().convertValue(this, Map.class);
  }
}
