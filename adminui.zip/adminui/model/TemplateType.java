package com.optum.riptide.ezcommui.adminui.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TemplateType {
    private String type;
}
