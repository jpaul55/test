package com.optum.riptide.ezcommui.adminui.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class RemoveModel extends BaseModel{


    @JsonInclude
    private String menuEntityId;


    public RemoveModel(final String menuEntityId) {
        this.menuEntityId = menuEntityId;
    }


    @Override
    public String toString() {
        return super.toString();
    }
}
