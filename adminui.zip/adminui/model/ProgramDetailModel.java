package com.optum.riptide.ezcommui.adminui.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Model for displaying detailed program information in the Manage Program IDs modal.
 * Contains: Program Description (from campaign.name), Program ID (from sms_manager_setting.program_id),
 * Client ID (from sms_manager_setting.oauth_client_id), Sender Name and Sender Email (from email_setting).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProgramDetailModel {

    private Integer campaignId;           // campaign.campaign_id
    private String programDescription;    // campaign.name (Program Description)
    private String programId;             // sms_manager_setting.program_id
    private String clientId;              // sms_manager_setting.oauth_client_id
    private String senderName;            // email_setting.sender_name
    private String senderEmail;           // email_setting.sender_email_address
    private Long smsManagerSettingId;     // sms_manager_setting.sms_manager_setting_id
    private Long emailSettingId;          // email_setting.email_setting_id

}

