package com.optum.riptide.ezcommui.adminui.model;

import lombok.Data;

@Data
public class TemplateParam {
    public String urlLink;
    public String urlLabel;

 public TemplateParam(final String urlLink, final String urlLabel) {
     this.urlLink = urlLink;
     this.urlLabel = urlLabel;
 }

@Override
public String toString(){
    return "{\"msg_parameters\": " +
            "{\"template\": {" +
            "\"urlLink\": \""+urlLink+"\", " +
            "\"urlLabel\": \""+urlLabel+"\"}}}";
}
}

