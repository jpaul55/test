package com.optum.riptide.ezcommui.adminui.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class BaseModel {

    @Override
    public String toString() {
        final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
        try{
            return OBJECT_MAPPER.writeValueAsString(this);
        } catch (JsonProcessingException e){
            return String.valueOf(this);
        }
    }
}
