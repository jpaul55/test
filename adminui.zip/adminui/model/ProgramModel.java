package com.optum.riptide.ezcommui.adminui.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class ProgramModel extends BaseModel{
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer settingId;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String description;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String senderEmail;

    public ProgramModel(final Integer settingId, final String description) {
        this.settingId = settingId;
        this.description = description;
    }

    public ProgramModel(final Integer settingId, final String description, final String senderEmail) {
        this.settingId = settingId;
        this.description = description;
        this.senderEmail = senderEmail;
    }
}
