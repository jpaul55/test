package com.optum.riptide.ezcommui.adminui.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.riptide.ezcommui.adminui.entities.MenuEntity;
import com.optum.riptide.ezcommui.adminui.entities.NotificationTemplate;
import com.optum.riptide.ezcommui.adminui.enums.NotifTemplateType;
import com.optum.riptide.ezcommui.adminui.utils.TemplateParamsUtils;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.list.TreeList;
import org.apache.commons.lang3.StringUtils;

@Data
@NoArgsConstructor
public class AuditTrailModel {
    private long id;
    private String campaignName;
    private String url;
    private String label;
    private Integer program;
    private Long standardTemplateId;
    private long clientContextId;
    private String interactionType;
    private List<AuditTrailCampaignFilterModel> campaignFilter;
    private String subjectLine;
    private String disclaimer;
    private String senderEmail;

    public AuditTrailModel(final Long id, final String campaignName, final String url, final String label,
                           final Integer program, final Long standardTemplateId, final long clientContextId,
                           final String interactionType, final List<AuditTrailCampaignFilterModel> campaignFilter,
                           final String subjectLine, final String disclaimer, final String senderEmail) {
        this.id = id;
        this.campaignName = campaignName;
        this.url = url;
        this.label = label;
        this.program = program;
        this.standardTemplateId = standardTemplateId;
        this.clientContextId = clientContextId;
        this.interactionType = interactionType;
        this.campaignFilter = campaignFilter;
        this.subjectLine = subjectLine;
        this.disclaimer = disclaimer;
        this.senderEmail = senderEmail;
    }

    public String convertToJson() {
        ObjectMapper Obj = new ObjectMapper();
        try {
            String jsonObj = Obj.writeValueAsString(this);
            return jsonObj;
        } catch (IOException io) {
            return null;
        }
    }

    public static AuditTrailModel instanceForNewValue(final CampaignModel campaign, final long menuId, final Long standardTemplateId,
                                                      final String interactionType) {
        String urlLink = StringUtils.isNotBlank(campaign.getUrlLinkEmail()) ? campaign.getUrlLinkEmail() : campaign.getUrlLinkSMS();
        AuditTrailModel auditTrailModel = new AuditTrailModel();
        auditTrailModel.setId(menuId);
        auditTrailModel.setCampaignName(campaign.getName());
        auditTrailModel.setUrl(urlLink);
        auditTrailModel.setLabel(campaign.getUrlLabel());
        auditTrailModel.setProgram(campaign.getSettingId());
        auditTrailModel.setStandardTemplateId(standardTemplateId);
        auditTrailModel.setClientContextId(campaign.getClientContextId());
        auditTrailModel.setInteractionType(interactionType);
        auditTrailModel.setSubjectLine(campaign.getSubjectLine());
        auditTrailModel.setDisclaimer(campaign.getDisclaimer());
        auditTrailModel.setSenderEmail(campaign.getSenderEmail());
        if (campaign.getCampaignFilters() != null && !campaign.getCampaignFilters().isEmpty()) {
            campaign.getCampaignFilters().stream().forEach(cf -> {
                if (!cf.isDelete()) {
                    auditTrailModel.addCampaignFilter(cf);
                }
            });
        }
        return auditTrailModel;
    }

    public static AuditTrailModel instanceOf(final MenuEntity menuEntity, final CampaignModel campaign) {
        AuditTrailModel auditTrailModel = new AuditTrailModel();
        auditTrailModel.setId(menuEntity.getMenuEntityId());
        auditTrailModel.setCampaignName(menuEntity.getName());
        auditTrailModel.setProgram(menuEntity.getCampaign().getCampaignId());
        auditTrailModel.setClientContextId(menuEntity.getClientContextList().get(0).getClientContextId());
        auditTrailModel.setSubjectLine(menuEntity.getSubjectLine());
        auditTrailModel.setDisclaimer(campaign.getDisclaimer());
        auditTrailModel.setSenderEmail(campaign.getSenderEmail());
        List<NotificationTemplate> templateList = menuEntity.getNotificationTemplateList().stream().filter(t->
                NotifTemplateType.SMS.toString().equalsIgnoreCase(t.getTemplateType().getTemplateTypeValue())
                        || NotifTemplateType.EMAIL.toString().equalsIgnoreCase(t.getTemplateType().getTemplateTypeValue())
        ).toList();;
        if (!templateList.isEmpty()) {
            NotificationTemplate template = templateList.get(0);
            auditTrailModel.setUrl(TemplateParamsUtils.extractUrlLink(template.getTemplateParams()));
            auditTrailModel.setLabel(TemplateParamsUtils.extractUrlLabel(template.getTemplateParams()));
            auditTrailModel.setStandardTemplateId(template.getStandardTemplate() != null ?
                    template.getStandardTemplate().getStandardTemplateId() : 0);
            auditTrailModel.setInteractionType(templateList.size() == 1 ?
                    NotifTemplateType.valueOf(template.getTemplateType().getTemplateTypeValue()).getInteractionType() :
                    NotifTemplateType.BOTH.getInteractionType());
        }
        if (campaign.getCampaignFilters() != null && !campaign.getCampaignFilters().isEmpty()) {
            campaign.getCampaignFilters().stream().forEach(cf -> {
                if (cf.getFilterEntryId() != 0) {
                    auditTrailModel.addCampaignFilter(cf);
                }
            });
        }
        return auditTrailModel;
    }

    private void addCampaignFilter(CampaignFilterModel campaignFilter) {
        if (this.campaignFilter == null) {
            this.campaignFilter = new TreeList();
        }
        this.campaignFilter.add(new AuditTrailCampaignFilterModel(campaignFilter.getCategory(), campaignFilter.getRule(), campaignFilter.getValue()));
    }

}
