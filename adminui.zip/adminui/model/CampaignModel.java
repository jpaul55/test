package com.optum.riptide.ezcommui.adminui.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class CampaignModel extends BaseModel{
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private long clientContextId;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String name;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("campaignName")
    private String campaignName;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String urlLinkEmail;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String urlLinkSMS;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String urlLabel;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer settingId;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<String> templateTypes;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<CampaignFilterModel> campaignFilters;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Long messageTemplateId;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String subjectLine;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String title;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String description;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String disclaimer;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String senderEmail;


  public CampaignModel(final long clientContextId, final String name, final String campaignName, final String urlLinkEmail, final String urlLinkSMS,
                         final String urlLabel, final Integer settingId, final List<String> templateTypes,
                         final Long messageTemplateId, final String subjectLine, final String title, final String description,
                         final String disclaimer, final String senderEmail) {
        this.clientContextId = clientContextId;
        this.name = name;
        this.campaignName = campaignName;
        this.urlLinkEmail = urlLinkEmail;
        this.urlLinkSMS = urlLinkSMS;
        this.urlLabel = urlLabel;
        this.settingId = settingId;
        this.templateTypes = templateTypes;
        this.messageTemplateId = messageTemplateId;
        this.subjectLine = subjectLine;
        this.title = title;
        this.description = description;
        this.disclaimer = disclaimer;
        this.senderEmail = senderEmail;
    }
}
