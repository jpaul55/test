package com.optum.riptide.ezcommui.adminui.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.riptide.api.nesslogger.annotations.NessEvent;
import com.optum.riptide.ezcommui.adminui.constants.AdminUiPropertiesBean;
import com.optum.riptide.ezcommui.core.campaign.MenuRequest;
import com.optum.stargate.client.auth.StargateAuthException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import com.google.json.JsonSanitizer;
import org.springframework.http.HttpMethod;
import java.net.URI;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.cache.annotation.Cacheable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.optum.riptide.api.nesslogger.annotations.NessEvent;
import com.optum.riptide.ezcommui.adminui.constants.AdminUiPropertiesBean;
import com.optum.riptide.ezcommui.adminui.entities.ClientContext;
import com.optum.riptide.ezcommui.adminui.entities.MenuEntity;
import com.optum.riptide.ezcommui.adminui.model.CampaignModel;
import com.optum.riptide.ezcommui.adminui.service.EzcommAdminService;
import com.optum.riptide.ezcommui.adminui.valueobjects.request.MenusRequest;
import com.optum.riptide.ezcommui.adminui.valueobjects.request.SaveBoBItemsRequest;
import com.optum.riptide.ezcommui.adminui.valueobjects.request.SaveProgramIdsRequest;
import com.optum.riptide.ezcommui.adminui.valueobjects.response.CampaignVO;
import com.optum.riptide.ezcommui.adminui.valueobjects.response.DeleteBoBItemResponse;
import com.optum.riptide.ezcommui.adminui.valueobjects.response.DeleteProgramIdResponse;
import com.optum.riptide.ezcommui.adminui.valueobjects.response.FilterItemVO;
import com.optum.riptide.ezcommui.adminui.valueobjects.response.ProgramIdVO;
import com.optum.riptide.ezcommui.adminui.valueobjects.response.SaveBoBItemsResponse;
import com.optum.riptide.ezcommui.adminui.valueobjects.response.SaveProgramIdsResponse;
import com.optum.riptide.ezcommui.adminui.valueobjects.response.TemplateVO;
import com.optum.riptide.ezcommui.adminui.entities.FilterCategoryItem;
import com.optum.riptide.ezcommui.adminui.entities.SmsManagerSetting;
import org.apache.commons.lang3.*;
import org.springframework.web.bind.annotation.*;
import com.optum.stargate.client.auth.StargateClientOAuth2;
import jakarta.validation.Valid;
import java.util.stream.Collectors;

@Slf4j


@RestController
@CrossOrigin
@RequestMapping("/admin")
public class AdminUiController {

    static final String NO_CACHE = "no-cache";
    final AdminUiPropertiesBean propertiesBean;
    final EzcommAdminService ezcommAdminService;
    final RestTemplate restTemplate;
  final ObjectMapper objectMapper;

    final StargateClientOAuth2 stargateClientOAuth2;

    @Autowired
    public AdminUiController(
            AdminUiPropertiesBean propertiesBean,
            EzcommAdminService ezcommAdminService,
            @Qualifier("sslRestTemplate") RestTemplate restTemplate, @Qualifier("stargateClientOAuth2") StargateClientOAuth2 stargateClientOAuth2, ObjectMapper objectMapper) {
        this.propertiesBean = propertiesBean;
        this.objectMapper = objectMapper;
        this.ezcommAdminService = ezcommAdminService;
        this.restTemplate = restTemplate;
        this.stargateClientOAuth2 = stargateClientOAuth2;
    }


    @GetMapping(path = "/client-contexts")
    public ResponseEntity<List<ClientContext>> getClientContext() {

        try {
            final List<ClientContext> clientContextList =
                    ezcommAdminService.retrieveClientContextByRoles();
            return new ResponseEntity<>(clientContextList, HttpStatus.OK);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @PostMapping("/campaigns")
    public ResponseEntity<Object> postCampaign(
            @RequestBody final CampaignModel newCampaign) {

        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.set(HttpHeaders.CACHE_CONTROL, NO_CACHE);
            return new ResponseEntity<>(
                    ezcommAdminService.createCampaign(newCampaign), headers, HttpStatus.OK);
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @DeleteMapping("/campaigns/{id}")
    public ResponseEntity<Object> deleteCampaign(
            @PathVariable("id") final long campaignId) {

        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.set(HttpHeaders.CACHE_CONTROL, NO_CACHE);

            return new ResponseEntity<>(
                    ezcommAdminService.deleteCampaign(campaignId), headers, HttpStatus.OK);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @PutMapping("/campaigns/{id}")
    public ResponseEntity<Object> putCampaign(
            @PathVariable("id") final long menuId,
            @RequestBody final CampaignModel campaign) {

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set(HttpHeaders.CONTENT_TYPE, "application/json");
            headers.set(HttpHeaders.CACHE_CONTROL, NO_CACHE);
            CampaignModel updatedCampaign =
                    ezcommAdminService.updateCampaign(menuId, cleanCampaign(campaign));
            return new ResponseEntity<Object>(updatedCampaign, headers, HttpStatus.OK);
        } catch (ResponseStatusException e) {
            log.error(e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    private CampaignModel cleanCampaign(final CampaignModel campaign) {
        CampaignModel cleaned = new CampaignModel();
        cleaned.setClientContextId(campaign.getClientContextId());
        cleaned.setSettingId(campaign.getSettingId());
        cleaned.setTemplateTypes(campaign.getTemplateTypes());
        cleaned.setName(campaign.getName());
        cleaned.setCampaignName(campaign.getCampaignName());  // Add campaignName field
        cleaned.setUrlLabel(campaign.getUrlLabel());
        cleaned.setUrlLinkEmail(campaign.getUrlLinkEmail());
        cleaned.setUrlLinkSMS(campaign.getUrlLinkSMS());
        cleaned.setMessageTemplateId(campaign.getMessageTemplateId());
        cleaned.setCampaignFilters(campaign.getCampaignFilters());
        cleaned.setSubjectLine(campaign.getSubjectLine());
        cleaned.setDescription(campaign.getDescription());
        cleaned.setTitle(campaign.getTitle());
        cleaned.setDisclaimer(campaign.getDisclaimer());
        cleaned.setSenderEmail(campaign.getSenderEmail());
        return cleaned;
    }

    @NessEvent
    @GetMapping("/programs")
    public ResponseEntity<Object> getPrograms() {

        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.set(HttpHeaders.CACHE_CONTROL, NO_CACHE);
            return new ResponseEntity<>(ezcommAdminService.retrievePrograms(), headers, HttpStatus.OK);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @GetMapping("/program-details")
    public ResponseEntity<Object> getProgramDetails() {
        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.set(HttpHeaders.CACHE_CONTROL, NO_CACHE);
            return new ResponseEntity<>(ezcommAdminService.retrieveProgramDetails(), headers, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error fetching program details", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @PostMapping("/program-details")
    public ResponseEntity<Object> saveProgramDetails(
            @Valid @RequestBody com.optum.riptide.ezcommui.adminui.valueobjects.request.SaveProgramDetailsRequest request) {
        try {
            log.info("========== SAVE PROGRAM DETAILS ENDPOINT CALLED ==========");
            log.info("Received request with {} existing items, {} new items",
                request.getExistingItems() != null ? request.getExistingItems().size() : 0,
                request.getNewItems() != null ? request.getNewItems().size() : 0);

            var response = ezcommAdminService.saveProgramDetails(request);

            log.info("========== SAVE PROGRAM DETAILS ENDPOINT COMPLETED ==========");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error saving program details", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

  @NessEvent
//  @Cacheable(value = "campaigns", key = "#clientContextId")
  @GetMapping(value = "/campaigns")
  public ResponseEntity<List<CampaignVO>> getCampaignNames(@RequestParam(value = "clientContextId") final long clientContextId) throws StargateAuthException {
    log.debug("Received request for campaigns with clientContextId: {}", clientContextId);
    String url = propertiesBean.menuEntityUrl;
    MenuRequest menuRequest = new MenuRequest();
    menuRequest.setLauncherRequestBody(new MenuRequest.LauncherRequestBody());
    menuRequest.setMemberDetails(new MenuRequest.MemberDetails());
    menuRequest.getLauncherRequestBody().setClientContextId(clientContextId);

    HttpHeaders headers = new HttpHeaders();
    headers.setBearerAuth(stargateClientOAuth2.getStargateOAuthToken());
    headers.setContentType(MediaType.APPLICATION_JSON);

    try {
      RequestEntity<MenuRequest> requestEntity = new RequestEntity<>(menuRequest, headers, HttpMethod.POST, URI.create(url));
      ResponseEntity<List<MenuEntity>> responseEntity = restTemplate.exchange(requestEntity, new ParameterizedTypeReference<List<MenuEntity>>() {});
      return validateCampaign(responseEntity);
    } catch (HttpClientErrorException | HttpServerErrorException e) {
      log.warn("Client/Server error occurred: {}", e.getResponseBodyAsString(), e);
      return ResponseEntity.status(e.getStatusCode()).build();
    } catch (Exception e) {
      log.error("Error occurred while making the API call", e);
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
  }

  @NessEvent
    @GetMapping("/filter-category-items")
    public ResponseEntity<Object> getFilterCategoryItems() {
        try {
            log.info("========== GET FILTER CATEGORY ITEMS ENDPOINT CALLED ==========");
            List<FilterItemVO> items = ezcommAdminService.getFilterCategoryItems();

            // Count BoB items specifically
            long bobCount = items.stream()
                .filter(item -> "BoB".equals(item.getFilterCategoryCode()))
                .count();

            log.info("Returning {} total filter category items, including {} BoB items", items.size(), bobCount);

            // Log all BoB items for debugging
            items.stream()
                .filter(item -> "BoB".equals(item.getFilterCategoryCode()))
                .forEach(item -> log.info("BoB item: {} - {}", item.getCode(), item.getDescription()));

            final HttpHeaders headers = new HttpHeaders();
            log.info("========== GET FILTER CATEGORY ITEMS ENDPOINT COMPLETED ==========");
            return new ResponseEntity<>(items, headers, HttpStatus.OK);
        } catch (Exception e) {
            log.error("========== ERROR IN GET FILTER CATEGORY ITEMS ENDPOINT ==========", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @GetMapping("/filter-categories")
    public ResponseEntity<Object> getFilterCategories() {
        try {
            final HttpHeaders headers = new HttpHeaders();
            return new ResponseEntity<>(ezcommAdminService.getFilterCategories(), headers, HttpStatus.OK);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @PostMapping("/filter-category-items/bob")
    public ResponseEntity<Object> saveBoBItems(
            @Valid @RequestBody final SaveBoBItemsRequest request) {
        try {
            log.info("========== SAVE BOB ITEMS ENDPOINT CALLED ==========");
            log.info("Received request with {} BoB items", request.getBobItems().size());
            log.info("Request details: {}", JsonSanitizer.sanitize(request.toString()));

            List<FilterCategoryItem> bobItemsToSave = request.getBobItems().stream()
                .map(dto -> {
                    FilterCategoryItem item = new FilterCategoryItem();
                    // IMPORTANT: Set the ID if it exists (for updates), leave null for new items
                    if (dto.getId() != null && dto.getId() > 0) {
                        item.setId(dto.getId());
                    }
                    item.setFilterCategoryCd("BoB");
                    item.setCode(dto.getCode());
                    item.setDescription(dto.getDescription());
                    log.info("Mapping DTO to entity - ID: {}, Code: {}, Description: {}",
                        dto.getId(), dto.getCode(), dto.getDescription());
                    return item;
                })
                .collect(Collectors.toList());

            log.info("Calling service layer to save {} items", bobItemsToSave.size());
            SaveBoBItemsResponse response = ezcommAdminService.saveBoBItems(bobItemsToSave);
            log.info("Service layer returned {} saved items, hasWarnings: {}",
                response.getSavedItems().size(), response.isHasWarnings());

            final HttpHeaders headers = new HttpHeaders();
            log.info("========== SAVE BOB ITEMS ENDPOINT COMPLETED SUCCESSFULLY ==========");
            return new ResponseEntity<>(response, headers, HttpStatus.OK);
        } catch (Exception e) {
            log.error("========== ERROR IN SAVE BOB ITEMS ENDPOINT ==========", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @DeleteMapping("/filter-category-items/bob/{code}")
    public ResponseEntity<Object> deleteBoBItem(@PathVariable String code) {
        try {
            log.info("========== DELETE BOB ITEM ENDPOINT CALLED ==========");
            log.info("Attempting to delete BoB item with code: {}", JsonSanitizer.sanitize(code));

            DeleteBoBItemResponse response = ezcommAdminService.deleteBoBItem(code);

            if (!response.isSuccess()) {
                log.warn("Cannot delete BoB item: {}", response.getMessage());
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }

            log.info("========== DELETE BOB ITEM ENDPOINT COMPLETED SUCCESSFULLY ==========");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            log.error("========== ERROR IN DELETE BOB ITEM ENDPOINT ==========", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @DeleteMapping("/program-ids/{settingId}")
    public ResponseEntity<Object> deleteProgramId(@PathVariable Long settingId) {
        try {
            log.info("========== DELETE PROGRAM ID ENDPOINT CALLED ==========");
            log.info("Attempting to delete Program ID with settingId: {}", settingId);

            DeleteProgramIdResponse response = ezcommAdminService.deleteProgramId(settingId);

            if (!response.isSuccess()) {
                log.warn("Cannot delete Program ID: {}", response.getMessage());
                return new ResponseEntity<>(response, HttpStatus.CONFLICT);
            }

            log.info("========== DELETE PROGRAM ID ENDPOINT COMPLETED SUCCESSFULLY ==========");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            log.error("========== ERROR IN DELETE PROGRAM ID ENDPOINT ==========", e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @PostMapping("/templates")
    public ResponseEntity<String> getTemplateBody(
            @RequestBody final String payload) {


        ResponseEntity<String> templates;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set(HttpHeaders.CONTENT_TYPE, "application/json");
            headers.setBearerAuth(stargateClientOAuth2.getStargateOAuthToken());

            HttpEntity<String> request = new HttpEntity<>(payload, headers);
            templates = restTemplate.postForEntity(propertiesBean.templateUrl, request, String.class);
            return validateTemplate(templates, propertiesBean.templateUrl);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @NessEvent
    @GetMapping("/templates/messageTemplates")
    public ResponseEntity<Object> getStandardTemplate() {
        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.set(HttpHeaders.CACHE_CONTROL, NO_CACHE);
            return new ResponseEntity<>(
                    ezcommAdminService.retrieveMessageTemplate(), headers, HttpStatus.OK);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    private ResponseEntity<String> validateTemplate(
            ResponseEntity<String> responseEntity, String requestUrl) {
        if (StringUtils.isBlank(responseEntity.getBody())
                || StringUtils.isEmpty(responseEntity.getBody())) {
            return new ResponseEntity<>(
                    "Error calling endpoint: " + requestUrl, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        TemplateVO templateVO =
                new TemplateVO(StringEscapeUtils.unescapeHtml3(responseEntity.getBody()));
        return new ResponseEntity<>(templateVO.getBody(), HttpStatus.OK);
    }

  private ResponseEntity<List<CampaignVO>> validateCampaign(ResponseEntity<List<MenuEntity>> responseEntity) {
    if (responseEntity.getBody() == null || responseEntity.getBody().isEmpty()) {
      return ResponseEntity.ok(Collections.emptyList());
    }

    List<CampaignVO> campaignList = ezcommAdminService.menuEntityToCampaignVOList(responseEntity.getBody());
    return ResponseEntity.ok(campaignList);
  }
  @NessEvent
  @GetMapping("/menu-entity/{id}")
  public ResponseEntity<Object> getMenuEntityDetails(@PathVariable("id") long menuEntityId) {
    try {
      Object[] result = ezcommAdminService.getCampaignIdAndTitleAndDescription(menuEntityId);
      return new ResponseEntity<>(result, HttpStatus.OK);
    } catch (ResponseStatusException e) {
      log.error(e.getMessage(), e);
      throw e;
    } catch (Exception e) {
      log.error(e.getMessage(), e);
      throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
    }
  }

  @NessEvent
  @PutMapping("/menu-entity/{id}")
  public ResponseEntity<Object> updateMenuEntityDetails(
      @PathVariable("id") long menuEntityId,
      @RequestBody Map<String, String> requestBody) {
    try {
      String title = requestBody.get("title");
      String description = requestBody.get("description");
      MenuEntity updatedMenuEntity = ezcommAdminService.updateTitleAndDescription(menuEntityId, title, description);
      return new ResponseEntity<>(updatedMenuEntity, HttpStatus.OK);
    } catch (ResponseStatusException e) {
      log.error(e.getMessage(), e);
      throw e;
    } catch (Exception e) {
      log.error(e.getMessage(), e);
      throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
    }
  }

  // ==================== PROGRAM ID ENDPOINTS ====================

  /**
   * GET /admin/program-ids
   * Retrieve all Program IDs with their descriptions from campaign table
   */
  @NessEvent
  @GetMapping("/program-ids")
  public ResponseEntity<List<ProgramIdVO>> getProgramIds() {
      try {
          log.info("========== GET PROGRAM IDS ENDPOINT CALLED ==========");
          List<ProgramIdVO> programIds = ezcommAdminService.getProgramIds();
          log.info("Returning {} program IDs", programIds.size());
          log.info("========== GET PROGRAM IDS ENDPOINT COMPLETED ==========");
          return new ResponseEntity<>(programIds, HttpStatus.OK);
      } catch (Exception e) {
          log.error("========== ERROR IN GET PROGRAM IDS ENDPOINT ==========", e);
          throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
      }
  }

  /**
   * POST /admin/program-ids
   * Save/Update Program IDs
   */
  @NessEvent
  @PostMapping("/program-ids")
  public ResponseEntity<SaveProgramIdsResponse> saveProgramIds(
          @Valid @RequestBody SaveProgramIdsRequest request) {
      try {
          log.info("========== SAVE PROGRAM IDS ENDPOINT CALLED ==========");
          log.info("Received request with {} Program ID items", request.getProgramItems().size());

          log.info("Calling service layer to save {} Program ID items", request.getProgramItems().size());
          SaveProgramIdsResponse response = ezcommAdminService.saveProgramIds(request.getProgramItems());
          log.info("Service layer returned {} saved items, hasWarnings: {}",
              response.getSavedItems().size(), response.isHasWarnings());

          log.info("========== SAVE PROGRAM IDS ENDPOINT COMPLETED SUCCESSFULLY ==========");
          return new ResponseEntity<>(response, HttpStatus.OK);
      } catch (Exception e) {
          log.error("========== ERROR IN SAVE PROGRAM IDS ENDPOINT ==========", e);
          throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
      }
  }

}
