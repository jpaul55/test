package com.optum.riptide.ezcommui.adminui.entities;

import jakarta.persistence.*;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Data
@Table
@NoArgsConstructor
public class FilterRule {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
  @GenericGenerator(name = "native")
  @Column(columnDefinition = "int")
  private long filterRuleId;

    private long menuEntityId;
    private String filterType;
    private String filterCategoryCd;

    @OneToMany(mappedBy = "filterRule", cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH},
            fetch = FetchType.LAZY)
    private List<FilterEntry> filterEntryList;

}
