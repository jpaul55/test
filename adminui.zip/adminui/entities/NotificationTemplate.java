package com.optum.riptide.ezcommui.adminui.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

/** Created by hrachako on 7/18/19. */
@Entity
@Data
@Table
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(
    ignoreUnknown = true,
    value = {"menuEntityList"})
public class NotificationTemplate {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
  @GenericGenerator(name = "native")
  @Column(columnDefinition = "int")
  @JsonProperty("notificationId")
  private long notificationTemplateId;

  private String name;

  @Column(columnDefinition = "TEXT")
  private String templateBody;

  private String templateParams;

  @ManyToOne(
      cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH},
      fetch = FetchType.EAGER)
  @JoinColumn(name = "template_type")
  private TemplateType templateType;

  @ManyToMany(
      mappedBy = "notificationTemplateList",
      cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH},
      fetch = FetchType.LAZY)
  private List<MenuEntity> menuEntityList;

  @ManyToOne(
      cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH},
      fetch = FetchType.EAGER)
  @JoinColumn(name = "standard_template_id")
  private StandardTemplate standardTemplate;
}
