package com.optum.riptide.ezcommui.adminui.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Data
@Table
@NoArgsConstructor
public class FilterEntry {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
  @GenericGenerator(name = "native")
  @Column(columnDefinition = "int")
  private long filterEntryId;

    @ManyToOne
    @JoinColumn(name="filter_rule_id", nullable=false)
    private FilterRule filterRule;

    private String value;

}
