package com.optum.riptide.ezcommui.adminui.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.util.List;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

/**
 * Created by hrachako on 7/18/19.
 */
@Entity
@Table
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MenuEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
  @GenericGenerator(name = "native")
  @Column(columnDefinition = "int")
  @JsonProperty("menuId")
  private long menuEntityId;

  @Column(name = "name")
  private String name;

  @Column(name = "campaign_name")
  private String campaignName;

  @Column(name = "subject_line")
  private String subjectLine;
  private String disclaimer;

  @Column(name = "title")
  private String title;

  @Column(name = "description")
  private String description;

  @Transient
  @JsonProperty
  @SerializedName("senderEmail")
  private String senderEmail;

    @ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH},
            fetch = FetchType.EAGER)
    @JoinColumn(name = "campaign_id")
    private Campaign campaign;

    @ManyToMany
            (cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH},
                    fetch = FetchType.LAZY)
    @JoinTable(
            name = "menu_to_notifications",
            joinColumns = @JoinColumn(name = "menu_entity_id"),
            inverseJoinColumns = @JoinColumn(name = "notification_template_id"))
    private List<NotificationTemplate> notificationTemplateList;

    @ManyToMany
            (cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH},
                    fetch = FetchType.LAZY)
    @JoinTable(
            name = "menu_to_client_context",
            joinColumns = @JoinColumn(name = "menu_entity_id"),
            inverseJoinColumns = @JoinColumn(name = "client_context_id"))
    private List<ClientContext> clientContextList;

}
