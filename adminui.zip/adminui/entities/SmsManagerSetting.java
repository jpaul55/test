package com.optum.riptide.ezcommui.adminui.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity representing the sms_manager_setting table.
 * Stores Program ID information for EPMP (Email Program Management).
 */
@Entity
@Table(name = "sms_manager_setting")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SmsManagerSetting {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sms_manager_setting_id", columnDefinition = "int")
    private Long settingId;

    @Column(name = "program_id")
    private String programId;

    @Column(name = "oauth_client_id")
    private String oauthClientId;

    @Column(name = "epmp_program_flag")
    private String epmpProgramFlag;

    @Column(name = "epmp_category")
    private String epmpCategory;

}

