package com.optum.riptide.ezcommui.adminui.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;

/**
 * Entity representing the campaign_to_sms_manager_setting junction table.
 * Links Campaign with SmsManagerSetting.
 * Uses composite key since the table doesn't have a surrogate id column.
 */
@Entity
@Table(name = "campaign_to_sms_manager_setting")
@Data
@AllArgsConstructor
@NoArgsConstructor
@IdClass(CampaignToSmsManagerSetting.CampaignToSmsManagerSettingId.class)
public class CampaignToSmsManagerSetting {

    @Id
    @Column(name = "campaign_id")
    private Integer campaignId;

    @Id
    @Column(name = "sms_manager_setting_id")
    private Integer smsManagerSettingId;

    @Column(name = "usage_type")
    private String usageType;

    // Composite Key class
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CampaignToSmsManagerSettingId implements Serializable {
        private Integer campaignId;
        private Integer smsManagerSettingId;
    }
}

