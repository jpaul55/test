package com.optum.riptide.ezcommui.adminui.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Created by hrachako on 7/18/19. */
@Entity
@Data
@Table
@AllArgsConstructor
@NoArgsConstructor
public class TemplateType {
  @Id private String templateTypeValue;
}
