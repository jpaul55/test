package com.optum.riptide.ezcommui.adminui.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Data
@Table
@AllArgsConstructor
@NoArgsConstructor
public class StandardTemplate {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
  @GenericGenerator(name = "native")
  @Column(columnDefinition = "int")
  private Long standardTemplateId;

  private String name;
  private String description;
  private String emailTemplateBody;
  private String smsTemplateBody;
  private String defaultDisclaimer;

}
