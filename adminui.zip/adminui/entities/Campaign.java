package com.optum.riptide.ezcommui.adminui.entities;

import jakarta.persistence.*;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

/** Created by hrachako on 7/18/19. */
@Entity
@Data
@Table
@AllArgsConstructor
@NoArgsConstructor
public class Campaign {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
  @GenericGenerator(name = "native")
  @Column(columnDefinition = "int")
  private Integer campaignId;

  private String name;
  private String lob;
  private Boolean activeStatus;

  @Column(columnDefinition = "datetime NOT NULL DEFAULT CURRENT_TIMESTAMP", updatable = false)
  private Date created;

  @Column(
      columnDefinition = "datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
  private Date modified;

}
