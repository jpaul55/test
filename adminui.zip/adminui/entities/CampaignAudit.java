package com.optum.riptide.ezcommui.adminui.entities;

import jakarta.persistence.*;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Data
@Table
@AllArgsConstructor
@NoArgsConstructor
public class CampaignAudit {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
  @GenericGenerator(name = "native")
  @Column(columnDefinition = "int")
  private long campaignAuditId;

    private long menuEntityId;
    private String action;
    private String oldValue;
    private String newValue;
    private String userId;
    private Timestamp timestamp;
}
