package com.optum.riptide.ezcommui.adminui.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table
@AllArgsConstructor
@NoArgsConstructor
public class FilterCategoryItem {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(columnDefinition = "int")
  private Long id;

    private String filterCategoryCd;
    private String code;
    private String description;

}
