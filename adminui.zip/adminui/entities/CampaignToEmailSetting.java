package com.optum.riptide.ezcommui.adminui.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity representing the campaign_to_email_setting join table
 */
@Entity
@Data
@Table(name = "campaign_to_email_setting")
@NoArgsConstructor
@AllArgsConstructor
public class CampaignToEmailSetting {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "campaign_to_email_setting_id", nullable = false)
  private Integer campaignToEmailSettingId;

  @Column(name = "campaign_id", nullable = false)
  private Integer campaignId;

  @Column(name = "email_setting_id", nullable = false)
  private Long emailSettingId;
}

