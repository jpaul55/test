package com.optum.riptide.ezcommui.adminui.valueobjects.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response VO for Program ID information.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProgramIdVO {

    private Long settingId;                    // sms_manager_setting_id
    private String programIdDescription;        // Description from campaign.name (via junction)
    private String programId;                   // program_id from sms_manager_setting
    private String oauthClientId;              // oauth_client_id
    private String epmpProgramFlag;            // epmp_program_flag
    private String epmpCategory;               // epmp_category
}

