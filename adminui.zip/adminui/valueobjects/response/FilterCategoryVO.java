package com.optum.riptide.ezcommui.adminui.valueobjects.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FilterCategoryVO {

    private String filterCategoryCode;
    private String filterCategoryDescription;
    private String inputType;

}
