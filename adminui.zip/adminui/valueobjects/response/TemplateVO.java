package com.optum.riptide.ezcommui.adminui.valueobjects.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TemplateVO {

    private String body;
}
