package com.optum.riptide.ezcommui.adminui.valueobjects.response;

import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CampaignVO {

    private long clientContextId;
    private long menuId;
    /**
     * Represents the display name shown in the Admin UI.
     * This is distinct from {@code campaignName}, which is the display name shown in the EZComm list.
     */
    private String name;
    /**
     * Represents the display name shown in the EZComm list.
     * This is distinct from {@code name}, which is the display name shown in the Admin UI.
     */
    private String campaignName;
    private String urlLinkEmail;
    private String urlLinkSMS;
    private String urlLabel;
    private Integer settingId;
    private List<String> templateTypes;
    private boolean nonStandard;
    private List<CampaignFilterVO> campaignFilters;
    private Long messageTemplateId;
    private String subjectLine;
    private String disclaimer;
    private String defaultDisclaimer;
    private String senderEmail;

    public CampaignVO(long clientContextId, long menuId, String name, String campaignName, String urlLinkEmail, String urlLinkSMS, String urlLabel, Integer settingId,
                      List<String> templateTypes, boolean nonStandard, Long messageTemplateId, final String subjectLine, final String disclaimer, final String defaultDisclaimer,
                      String senderEmail) {
        this.clientContextId = clientContextId;
        this.menuId = menuId;
        this.name = name;
        this.campaignName = campaignName;
        this.urlLinkEmail = urlLinkEmail;
        this.urlLinkSMS = urlLinkSMS;
        this.urlLabel = urlLabel;
        this.settingId = settingId;
        this.templateTypes = templateTypes;
        this.nonStandard = nonStandard;
        this.messageTemplateId = messageTemplateId;
        this.campaignFilters = new ArrayList<>();
        this.subjectLine = subjectLine;
        this.disclaimer = disclaimer;
        this.defaultDisclaimer = defaultDisclaimer;
        this.senderEmail = senderEmail;
    }

    public void addCampaignFilterVO(CampaignFilterVO campaignFilterVO) {
        this.campaignFilters.add(campaignFilterVO);
    }

}
