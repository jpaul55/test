package com.optum.riptide.ezcommui.adminui.valueobjects.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CampaignFilterVO {

    private long filterEntryId;
    private String categoryName;
    private String category;
    private String rule;
    private String value;
    private String description;
    private boolean delete;

}
