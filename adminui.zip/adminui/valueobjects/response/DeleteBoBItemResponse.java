package com.optum.riptide.ezcommui.adminui.valueobjects.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response DTO for deleting a Book of Business (BoB) item.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeleteBoBItemResponse {

    private boolean success;
    private String message;
    private String code;  // The BoB code that was attempted to be deleted
    private boolean isTiedToCampaign;  // True if deletion failed because BoB is tied to campaigns
    private List<String> linkedCampaigns;  // List of campaign names that are linked to this BoB
}

