package com.optum.riptide.ezcommui.adminui.valueobjects.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response DTO for saving/updating Book of Business (BoB) items.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaveBoBItemsResponse {

    private List<FilterItemVO> savedItems;
    private List<String> warnings;
    private boolean hasWarnings;
}

