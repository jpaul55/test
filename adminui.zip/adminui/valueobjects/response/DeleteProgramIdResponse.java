package com.optum.riptide.ezcommui.adminui.valueobjects.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response object for deleting a Program ID.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeleteProgramIdResponse {
    private boolean success;
    private String message;
    private Long settingId;
    private boolean isLinkedToCampaigns;
    private List<String> linkedCampaigns;
}

