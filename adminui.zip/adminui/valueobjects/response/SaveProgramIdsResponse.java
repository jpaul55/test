package com.optum.riptide.ezcommui.adminui.valueobjects.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response DTO for saving/updating Program IDs.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaveProgramIdsResponse {

    private List<ProgramIdVO> savedItems;
    private List<String> warnings;
    private boolean hasWarnings;
}

