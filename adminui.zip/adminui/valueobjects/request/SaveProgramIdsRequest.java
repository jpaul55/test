package com.optum.riptide.ezcommui.adminui.valueobjects.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Request DTO for saving/updating Program IDs (SMS Manager Settings).
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaveProgramIdsRequest {

    @NotNull(message = "Program items list cannot be null")
    @NotEmpty(message = "Program items list cannot be empty")
    @Valid
    private List<ProgramIdDto> programItems;

    /**
     * Individual Program ID DTO.
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ProgramIdDto {
        private Long settingId;  // null for new items, > 0 for existing items

        @NotNull(message = "Program ID cannot be null")
        private String programId;

        private String programIdDescription;  // Program ID Description (user-editable)
        private String oauthClientId;      // OAuth Client ID
        private String epmpProgramFlag;    // EPMP Program Flag
        private String epmpCategory;       // EPMP Category
    }
}

