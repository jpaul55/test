package com.optum.riptide.ezcommui.adminui.valueobjects.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ClientContextRequest {
    private String lob;
}
