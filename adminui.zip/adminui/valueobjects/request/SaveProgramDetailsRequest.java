package com.optum.riptide.ezcommui.adminui.valueobjects.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Request DTO for saving/updating Program Details including email settings.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaveProgramDetailsRequest {

    @NotNull(message = "Program items list cannot be null")
    @Valid
    private List<ProgramDetailDto> existingItems;

    @Valid
    private List<ProgramDetailDto> newItems;

    /**
     * Individual Program Detail DTO.
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ProgramDetailDto {
        private Integer campaignId;           // campaign.campaign_id (null for new items)
        private String programDescription;    // campaign.name

        @NotNull(message = "Program ID cannot be null")
        private String programId;             // sms_manager_setting.program_id

        private String clientId;              // sms_manager_setting.oauth_client_id (can be null)
        private String senderName;            // email_setting.sender_name
        private String senderEmail;           // email_setting.sender_email_address
        private Long smsManagerSettingId;     // sms_manager_setting.sms_manager_setting_id
        private Long emailSettingId;          // email_setting.email_setting_id
    }
}

