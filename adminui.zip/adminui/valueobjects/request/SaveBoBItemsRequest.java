package com.optum.riptide.ezcommui.adminui.valueobjects.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Request DTO for saving/updating Book of Business (BoB) items.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaveBoBItemsRequest {

    @NotNull(message = "BoB items list cannot be null")
    @NotEmpty(message = "BoB items list cannot be empty")
    @Valid
    private List<BoBItemDto> bobItems;

    /**
     * Individual BoB item DTO.
     */
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class BoBItemDto {
        private Long id;  // null or 0 for new items, > 0 for existing items

        @NotNull(message = "BoB code cannot be null")
        private String code;

        @NotNull(message = "BoB description cannot be null")
        private String description;
    }
}

