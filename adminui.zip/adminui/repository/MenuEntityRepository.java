package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.MenuEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface MenuEntityRepository extends JpaRepository<MenuEntity, String> {

  MenuEntity getByMenuEntityId(final long id);

  MenuEntity findByMenuEntityIdAndClientContextList_ClientContextId(final long menuId, final long clientContextId);

  MenuEntity findByClientContextList_ClientContextIdAndNameIgnoreCase(final long clientContextId, final String name);

  @Query("SELECT m.title, m.description, m.campaign.campaignId FROM MenuEntity m WHERE m.menuEntityId = :menuEntityId")
  Object[] findCampaignIdTitleAndDescriptionByMenuEntityId(@Param("menuEntityId") long menuEntityId);

  // Find all menu entities linked to a specific campaign
  List<MenuEntity> findByCampaign_CampaignId(Integer campaignId);
}
