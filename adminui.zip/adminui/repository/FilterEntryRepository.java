package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.FilterEntry;
import com.optum.riptide.ezcommui.adminui.entities.FilterRule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Set;

public interface FilterEntryRepository extends JpaRepository<FilterEntry, Long> {
    List<FilterEntry> findByFilterRule (final FilterRule filterRule);

  List<FilterEntry> findByFilterRuleMenuEntityIdIn(Set<Long> menuIdsEntityIds);

  List<FilterEntry> findByValue(String value);

  boolean existsByValue(String value);

  // Check if a BoB code is in use by any campaign (checks both value and category)
  boolean existsByValueAndFilterRuleFilterCategoryCd(String value, String filterCategoryCd);

  // Find all FilterEntry records for a given BoB code
  List<FilterEntry> findByValueAndFilterRuleFilterCategoryCd(String value, String filterCategoryCd);
}
