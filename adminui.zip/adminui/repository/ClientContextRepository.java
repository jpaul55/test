package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.ClientContext;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientContextRepository extends JpaRepository<ClientContext, String> {
    ClientContext getByClientContextId (final Long id);
}
