package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.Campaign;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CampaignRepository extends JpaRepository<Campaign, Integer> {

    /**
     * Get all campaigns for the Program (EPMP) dropdown in Admin UI.
     * Returns: [campaignId, campaignName]
     * Uses ONLY campaign table, no joins - shows ALL campaigns without duplicates.
     * Ordered by campaign name alphabetically.
     */
    @Query(value = "SELECT c.campaign_id, c.name " +
                   "FROM campaign c " +
                   "WHERE c.active_status = 1 " +
                   "ORDER BY c.name ASC",
            nativeQuery = true)
    List<Object[]> findAllCampaignsWithProgramIds();

    /**
     * Get campaigns that have linked Program IDs for the modal display.
     * Returns: [campaignId, campaignName, smsManagerSettingId]
     * Uses JOIN to show only campaigns with actual program IDs.
     * For campaigns with multiple usage types, uses MIN to avoid duplicates.
     */
    @Query(value = "SELECT c.campaign_id, " +
                   "c.name, " +
                   "MIN(cts.sms_manager_setting_id) as sms_manager_setting_id " +
                   "FROM campaign c " +
                   "INNER JOIN campaign_to_sms_manager_setting cts ON c.campaign_id = cts.campaign_id " +
                   "WHERE cts.sms_manager_setting_id IS NOT NULL " +
                   "GROUP BY c.campaign_id, c.name " +
                   "ORDER BY c.name ASC",
            nativeQuery = true)
    List<Object[]> findCampaignsWithLinkedProgramIds();
}
