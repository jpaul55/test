package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.FilterCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FilterCategoryRepository extends JpaRepository<FilterCategory, String> {

}
