package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.FilterRule;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FilterRuleRepository extends JpaRepository<FilterRule, Long> {
    FilterRule findByFilterCategoryCdAndMenuEntityId(final String filterCategoryCd, final Long menuEntityId);
    List<FilterRule> findByMenuEntityId(final Long menuEntityId);
}
