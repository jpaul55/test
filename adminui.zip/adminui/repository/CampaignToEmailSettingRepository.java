package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.CampaignToEmailSetting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * Repository for campaign_to_email_setting join table operations
 */
public interface CampaignToEmailSettingRepository extends JpaRepository<CampaignToEmailSetting, Integer> {

  /**
   * Find email setting ID by campaign ID
   * @param campaignId the campaign ID
   * @return Optional of email setting ID
   */
  @Query("SELECT c.emailSettingId FROM CampaignToEmailSetting c WHERE c.campaignId = :campaignId")
  Optional<Long> findEmailSettingIdByCampaignId(@Param("campaignId") Integer campaignId);

  /**
   * Find all campaign to email setting mappings by campaign ID
   * @param campaignId the campaign ID
   * @return List of CampaignToEmailSetting
   */
  List<CampaignToEmailSetting> findByCampaignId(Integer campaignId);
}
