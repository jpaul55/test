package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.FilterCategoryItem;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FilterCategoryItemRepository extends JpaRepository<FilterCategoryItem, Long> {

    List<FilterCategoryItem> findByFilterCategoryCd(final String filterCategoryCd);

}
