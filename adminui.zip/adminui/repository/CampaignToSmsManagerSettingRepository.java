package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.CampaignToSmsManagerSetting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for CampaignToSmsManagerSetting junction table.
 */
@Repository
public interface CampaignToSmsManagerSettingRepository extends JpaRepository<CampaignToSmsManagerSetting, CampaignToSmsManagerSetting.CampaignToSmsManagerSettingId> {

    /**
     * Find all junction entries by sms_manager_setting_id.
     * Note: One SMS Manager Setting can be linked to multiple campaigns.
     */
    List<CampaignToSmsManagerSetting> findBySmsManagerSettingId(Long smsManagerSettingId);

    /**
     * Delete by sms_manager_setting_id
     */
    void deleteBySmsManagerSettingId(Long smsManagerSettingId);
}

