package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.EmailSetting;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EmailSettingRepository extends JpaRepository<EmailSetting, Long> {
    Optional<EmailSetting> findBySenderNameAndSenderEmailAddress(String senderName, String senderEmailAddress);
}

