package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.StandardTemplate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StandardTemplateRepository extends JpaRepository<StandardTemplate, Long> {
}
