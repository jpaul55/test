package com.optum.riptide.ezcommui.adminui.repository;

import com.optum.riptide.ezcommui.adminui.entities.SmsManagerSetting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for SmsManagerSetting entity.
 */
@Repository
public interface SmsManagerSettingRepository extends JpaRepository<SmsManagerSetting, Long> {

    /**
     * Find all Program IDs ordered by program_id.
     */
    List<SmsManagerSetting> findAllByOrderByProgramIdAsc();

    /**
     * Get Program ID Description from campaign table for a given setting_id.
     * This joins through campaign_to_sms_manager_setting to get the campaign.name as "Program ID Description"
     */
    @Query(value = "SELECT c.name FROM campaign c " +
                   "INNER JOIN campaign_to_sms_manager_setting cts ON c.campaign_id = cts.campaign_id " +
                   "WHERE cts.sms_manager_setting_id = :settingId " +
                   "LIMIT 1", nativeQuery = true)
    String getProgramIdDescription(@Param("settingId") Long settingId);

    /**
     * Get detailed program information for the Manage Program IDs modal.
     * Returns: [campaignId, programDescription (campaign.name), programId, clientId,
     *           senderName, senderEmail, smsManagerSettingId, emailSettingId]
     * Joins campaign -> campaign_to_sms_manager_setting -> sms_manager_setting
     * and campaign -> campaign_to_email_setting -> email_setting
     */
    @Query(value = "SELECT c.campaign_id, " +
                   "c.name as program_description, " +
                   "sms.program_id, " +
                   "sms.oauth_client_id as client_id, " +
                   "es.sender_name, " +
                   "es.sender_email_address as sender_email, " +
                   "sms.sms_manager_setting_id, " +
                   "es.email_setting_id " +
                   "FROM campaign c " +
                   "INNER JOIN campaign_to_sms_manager_setting cts ON c.campaign_id = cts.campaign_id " +
                   "INNER JOIN sms_manager_setting sms ON cts.sms_manager_setting_id = sms.sms_manager_setting_id " +
                   "LEFT JOIN campaign_to_email_setting ctes ON c.campaign_id = ctes.campaign_id " +
                   "LEFT JOIN email_setting es ON ctes.email_setting_id = es.email_setting_id " +
                   "WHERE c.active_status = 1 " +
                   "GROUP BY c.campaign_id, c.name, sms.program_id, sms.oauth_client_id, " +
                   "es.sender_name, es.sender_email_address, sms.sms_manager_setting_id, es.email_setting_id " +
                   "ORDER BY c.name ASC",
            nativeQuery = true)
    List<Object[]> findAllProgramDetails();
}

