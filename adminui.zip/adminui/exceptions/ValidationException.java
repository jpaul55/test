package com.optum.riptide.ezcommui.adminui.exceptions;

public class ValidationException extends RuntimeException {

    public ValidationException(final String message) {
        super(message);
    }
    
}
